<?php

namespace Controller;

/**
 * Controller mau
 * @param {type} parameter
 */
interface IActionImport {

    public function import();
}
