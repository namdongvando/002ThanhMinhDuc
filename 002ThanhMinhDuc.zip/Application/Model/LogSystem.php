<?php

namespace Application\Model;

class LogSystem extends \datatable\Admin {
    
}
