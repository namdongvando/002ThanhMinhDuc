<?php

namespace Module\dashboard\Controller;

define("AppDir", "Module/dashboard");
define("AppPath", "/Module/dashboard");

class facebookpixel extends \ApplicationM {

    static public $UserLayout = "user";

    function __construct() {

    }

    function index() {
        echo "soaivong01@gmail.com";
    }

}
?>

