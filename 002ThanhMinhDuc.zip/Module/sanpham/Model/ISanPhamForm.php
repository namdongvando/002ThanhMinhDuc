<?php

namespace Module\sanpham\Model;

interface ISanPhamForm {

    public static function Id($value = null);

    public static function Name($value = null);

    public static function Code($value = null);

    public static function Mota($value = null);

    public static function Gia($value = null);

    public static function HinhAnh($value = null);

    public static function DanhMuc($value = null);
}
?>

