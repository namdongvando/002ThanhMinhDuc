<?php

namespace Module\trungtambaohanh\Model;

interface ITrungTamBaoHanhForm {

    static public function Id($value = null);

    static public function Name($value = null);

    static public function Address($value = null);

    static public function Hotline($value = null);

    static public function TenNhanVien($value = null);

    static public function KhuVuc($value = null);

    static public function UserId($value = null);
}
?>

