<?php

namespace Module\rmm;

class config {

}
