<?php

namespace Module\khachhang\Model;

interface IKhachHangThanhToanForm {

    public static function Id($value = null);

    public static function Name($value = null);

    public static function MaKhachHang($value = null);

    public static function TenCongTy($value = null);

    public static function MaSoThue($value = null);

    public static function DiaChi($value = null);

    public static function STK($value = null);

    public static function NganHang($value = null);

    public static function Fax($value = null);

    public static function GhiChu($value = null);
}
?>

