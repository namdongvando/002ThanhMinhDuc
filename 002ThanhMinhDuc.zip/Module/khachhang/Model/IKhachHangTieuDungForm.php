<?php

namespace Module\khachhang\Model;

interface IKhachHangTieuDungForm {

    public static function Id($value = null);

    public static function Name($value = null);

    public static function Phone($value = null);

    public static function DiaChi($value = null);

    public static function CMNN($value = null);

    public static function GhiChu($value = null);

    public static function SubData($value = null);
}
?>

